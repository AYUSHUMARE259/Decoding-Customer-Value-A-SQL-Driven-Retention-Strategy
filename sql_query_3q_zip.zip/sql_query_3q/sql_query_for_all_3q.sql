use project_db;
-- q1 
SELECT
    value_tier,
    COUNT(*) AS customers,
    ROUND(AVG(`Purchase Amount (USD)`),2) AS avg_purchase_amount,
    ROUND(AVG(total_spend),2) AS avg_spend,
    ROUND(AVG(`Previous Purchases`),2) AS avg_previous_purchases,
    ROUND(AVG(purchase_frequency_score),2) AS avg_frequency,
    ROUND(AVG(engagement_score),3) AS avg_engagement,
    ROUND(AVG(`Review Rating`),2) AS avg_rating,
    ROUND(AVG(promo_dependency_score),2) AS avg_promo_dependency
FROM enriched_dataset
GROUP BY value_tier
ORDER BY avg_spend DESC;

SELECT
    Season,
    Category,
    COUNT(*) AS customers,
    ROUND(AVG(`Previous Purchases`),2) AS avg_previous_purchases,
    ROUND(AVG(total_spend),2) AS avg_spend,
    ROUND(AVG(`Review Rating`),2) AS avg_rating
FROM enriched_dataset
GROUP BY Season, Category
ORDER BY avg_previous_purchases DESC;

SELECT
    Location,
    COUNT(*) AS customers,
    ROUND(AVG(total_spend),2) AS avg_spend,
    ROUND(AVG(promo_dependency_score),2) AS avg_promo_dependency,
    ROUND(AVG(`Previous Purchases`),2) AS avg_previous_purchases,
    ROUND(AVG(`Review Rating`),2) AS avg_rating
FROM enriched_dataset
GROUP BY Location
ORDER BY avg_spend DESC;